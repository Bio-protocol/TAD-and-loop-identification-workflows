/beegfs/group_dv/software/source/standard-RAxML-8.2.9/raxmlHPC-PTHREADS-SSE3 -T 40 -f a -p 767 -x 23333 -#100 -m GTRGAMMA -n ncov9 -s aln_clean.fa
