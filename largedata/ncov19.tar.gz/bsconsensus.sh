/beegfs/group_dv/software/source/raxml-ng_v0.9.0/raxml-ng --consense MRE --tree RAxML_bootstrap.ncov9 --prefix consMRE
